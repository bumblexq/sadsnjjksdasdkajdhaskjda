import datetime
import time
from db import Database

db = Database('1.db')


def days_to_seconds(days):
    return days * 24 * 60 * 60

a = input()


how_day = input()
if how_day == 1:
        time_sub = int(time.time()) + days_to_seconds(1) 
        db.set_time_sub(a, time_sub)
elif how_day == 3:
        time_sub = int(time.time()) + days_to_seconds(3) 
        db.set_time_sub(a, time_sub)
elif how_day == 7:
        time_sub = int(time.time()) + days_to_seconds(7) 
        db.set_time_sub(a, time_sub)
elif how_day == 31:
        time_sub = int(time.time()) + days_to_seconds(31) 
        db.set_time_sub(a, time_sub)
