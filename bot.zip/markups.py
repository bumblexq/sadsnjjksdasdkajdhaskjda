from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

btnProfile = KeyboardButton("ПРОФИЛЬ")
btnSub = KeyboardButton("ПОДПИСКА")

btnEmail = KeyboardButton("email")




maiMenu = ReplyKeyboardMarkup(resize_keyboard = True)
maiMenu.add(btnProfile, btnEmail)
mainMenu = ReplyKeyboardMarkup(resize_keyboard = True)
mainMenu.add(btnProfile, btnSub)







btnSubSet = KeyboardButton("Выдать подписку")
modMenu = ReplyKeyboardMarkup(resize_keyboard = True)
modMenu.add(btnSubSet)


btnRoleSet = KeyboardButton("Выдать роль")
btnRoleDeSet = KeyboardButton("Снять роль")
stat = KeyboardButton("Статистика")
admMenu = ReplyKeyboardMarkup(resize_keyboard = True)
admMenu.add(btnSubSet, btnRoleSet, btnRoleDeSet, stat)

mMenu = ReplyKeyboardMarkup(resize_keyboard = True)
mMenu.add(btnProfile)



  


#ПЛОЩАДКИ
Vinted = ReplyKeyboardMarkup(resize_keyboard = True)
btnVintedIT = KeyboardButton("VINTED 🇮🇹")
btnVintedES = KeyboardButton("VINTED 🇪🇸")
btnVintedFR = KeyboardButton("VINTED 🇫🇷")
btnVintedCZ = KeyboardButton("VINTED 🇨🇿")
Vinted.add(btnVintedIT,btnVintedCZ)